package Errors;

public class EmptySetException extends Exception {

    public EmptySetException() {
    }

    public String toString() {
        return "Error while computing a set expression: the set is empty\n";
    }
}

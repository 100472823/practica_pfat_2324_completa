package Compiler;

public class DoubleDefExc extends CompilerExc {
     
  private String msg;

  public DoubleDefExc(String s) {
     msg = "Variable " + s + " has been declared twice\n";
       }

  public String toString() {
     return msg;
       }
}

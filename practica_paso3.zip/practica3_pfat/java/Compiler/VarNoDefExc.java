package Compiler;

public class VarNoDefExc extends CompilerExc {
     
  private String msg;

  public VarNoDefExc(String s) {
     msg = "Variable " + s + " has not been declared\n";
       }

  public String toString() {
     return msg;
       }
}

package AST;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;

public interface LDecl {
    // esta interfaz sera implementada
    // por la 2 clases de las 2 reglas de procuccion posibles

    public void ComputeAH1() throws CompilerExc;

    public void generateCode(BufferedWriter w) throws IOException;

}

package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class Intersec implements Exp {

    public Exp exp1;
    public Exp exp2;

    public Intersec(Exp exp1, Exp exp2) {

        this.exp1 = exp1;
        this.exp2 = exp2;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        if ((exp1.ComputeTyp() == Typ.tintset) && (exp2.ComputeTyp() == Typ.tintset)) {

            return Typ.tintset;

        } else {

            throw new TypExc("Error en EXP INTERSEC EXP");
        }
    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        exp1.generateCode(w);
        w.write(".intersectionSet(");
        exp2.generateCode(w);
        w.write(")");

    }
}

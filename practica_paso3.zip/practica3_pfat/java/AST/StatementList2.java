
package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class StatementList2 implements StatementList {

    private Statement st1;
    private StatementList stl1;

    public StatementList2(Statement st1, StatementList stl1) {

        this.st1 = st1;
        this.stl1 = stl1;

    }

    @Override
    public int ComputeSt_type() throws CompilerExc {
        // TODO

        if ((st1.ComputeSt_type() == Typ.tvoid) && (stl1.ComputeSt_type() == Typ.tvoid)) {
            return Typ.tvoid;

        } else {

            throw new TypExc("Error en STATEMENT PC STATEMENTLIST, STATEMENT LIST2");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException {

        st1.generateCode(w);

        stl1.generateCode(w);

    }

}
package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class Statement2 implements Statement {

    public StatementList stl1;
    public Exp exp1;

    public Statement2(Exp exp1, StatementList stl1) {

        this.stl1 = stl1;
        this.exp1 = exp1;

    }

    @Override
    public int ComputeSt_type() throws CompilerExc {
        // TODO

        if ((exp1.ComputeTyp() == Typ.tbool) && (stl1.ComputeSt_type() == Typ.tvoid)) {

            return Typ.tvoid;

        } else {

            throw new TypExc("Error en IF EXP THEN STATEMENTLIST END, STATEMENT 2");
        }
    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.newLine();
        w.write("if (");
        exp1.generateCode(w);
        w.write(")  {");
        stl1.generateCode(w);
        w.write("}");

    }

}

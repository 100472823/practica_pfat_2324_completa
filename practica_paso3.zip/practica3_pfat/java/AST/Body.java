package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;

public class Body {

    public StatementList stl1;

    public Body(StatementList stl1) {

        this.stl1 = stl1;

    }

    // Llamammos al de abajo para que calcule,
    // Su atributo St_ty

    public int ComputeSt_type() throws CompilerExc {

        return stl1.ComputeSt_type();

    }

    public void generateCode(BufferedWriter w) throws IOException {

        stl1.generateCode(w);

    }

}

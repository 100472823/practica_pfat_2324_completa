package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class Diyuncion implements Exp {

    public Exp exp1;
    public Exp exp2;
    // ningun atributo static en las clases ast

    public Diyuncion(Exp exp1, Exp exp2) {

        this.exp1 = exp1;
        this.exp2 = exp2;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        if ((exp1.ComputeTyp() == Typ.tbool) && (exp2.ComputeTyp() == Typ.tbool)) {

            return Typ.tbool;

        } else {

            throw new TypExc("Error en EXP OR EXP");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        exp1.generateCode(w);
        w.write("||");
        exp2.generateCode(w);

    }

}

package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class intset implements Exp {

    public ExpList exp1;

    public intset(ExpList exp1) {

        this.exp1 = exp1;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        if (exp1.ComputeLTyp() == Typ.tvoid) {

            return Typ.tintset;

        } else {

            throw new TypExc("Error en BRAC EXPLIST KET");
        }
    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.write("new IntSetA(new Vector<>(Arrays.asList( ");
        exp1.generateCode(w);
        w.write(")");
        w.write(")");
        w.write(")");

    }
}

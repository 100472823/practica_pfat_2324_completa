package AST;

import Compiler.*;
import java.io.*;

/* Non terminal <S> */
//Simbolo inicial de la gramatica
public interface s {

    public void ComputeAH1() throws CompilerExc;

    public int ComputeSt_type() throws CompilerExc;

    public void codeGenerator() throws IOException;

}

package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.SymbolTable;
import Compiler.TableEntry;
import Compiler.Typ;
import Compiler.TypExc;

public class Statement1 implements Statement {

    public Exp exp1;
    public String i1;

    // public final para todos.

    public Statement1(String i1, Exp exp1) {

        this.i1 = i1;
        this.exp1 = exp1;

    }

    @Override
    public int ComputeSt_type() throws CompilerExc {
        // TODO

        // Mi resultado va a depender de que
        // El resultado de mis hijos sea correcto

        if ((SymbolTable.getType(i1)) == exp1.ComputeTyp()) {

            return Typ.tvoid;

        } else {

            throw new TypExc("Error en IDENT ASIGN EXP STATEMENT1");
        }
    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.newLine();
        w.write(i1 + " = ");
        exp1.generateCode(w);
        w.write(";");
    }

}

package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.SymbolTable;

public class Nombre implements Exp {

    public String s1;
    // esto como se asocia con el ident1

    public Nombre(String s1) {
        this.s1 = s1;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        return SymbolTable.getType(s1);

    }

    public void generateCode(BufferedWriter w) throws IOException {

        w.write(s1);

    }

}

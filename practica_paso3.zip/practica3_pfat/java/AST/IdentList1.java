package AST;

import Compiler.*;
import java.io.*;

public class IdentList1 implements IdentList {

    public String i1;
    private int ah1;

    public IdentList1(String i1) {

        this.i1 = i1;

    }

    public void computeAH1(int type) throws CompilerExc {
        // TODO Auto-generated method stub
        ah1 = type;
        SymbolTable.newEntry(i1, ah1);

    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.write(i1);

    }
}

package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;

public class Emptyset implements Exp {

    public Emptyset() {

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        return Typ.tintset;

    }

    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.write("new IntSetA(new Vector<>())");

    }

}

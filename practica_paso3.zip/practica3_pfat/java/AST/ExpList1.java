package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class ExpList1 implements ExpList {

    public Exp Exp1;

    public ExpList1(Exp Exp1) {

        this.Exp1 = Exp1;

    }

    @Override
    public int ComputeLTyp() throws CompilerExc {
        // TODO

        if (Exp1.ComputeTyp() == Typ.tint) {

            return Typ.tvoid;

        } else {

            throw new TypExc("Error en EXP");
        }
    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO

        Exp1.generateCode(w);

    }
}

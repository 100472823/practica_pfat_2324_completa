package AST;

import Compiler.*;
import java.io.*;

public interface Decl {

    public void ComputeAH1() throws CompilerExc;
    // TODO Auto-generated method stub

    public void generateCode(BufferedWriter w) throws IOException;

}

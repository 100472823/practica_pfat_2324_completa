package Compiler;

public class TypExc extends CompilerExc {

  private String msg;

  private static final String msg0 = "undefined type error: ";
  private static final String msg1 = "Error in assignment: variable and expression type are different\n";
  private static final String msg2 = "Error in if statement: condition type is int\n";
  private static final String msg4 = "Type error in sum: operands should be of type int\n";
  private static final String msg8 = "Type error  in equals operator: operands should be of the same type\n";

  public TypExc(String mess) {

    msg = mess;

  }

  public String toString() {
    return msg;
  }
}

// Aqui tendria que moficiar los mensajes para referenciar,
// que 1, significa un error en statementlist

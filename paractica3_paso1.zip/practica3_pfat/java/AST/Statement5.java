package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.SymbolTable;
import Compiler.Typ;
import Compiler.TypExc;

public class Statement5 implements Statement {

    public String s1;

    public Statement5(String s1) {

        this.s1 = s1;

    }

    @Override
    public int ComputeSt_type() throws CompilerExc {
        // TODO

        if (SymbolTable.getType(s1) == Typ.tbool) {

            return Typ.tvoid;

        } else {

            throw new TypExc("Error en PRINTB PARENT IDENT TESIS");
        }
    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.newLine();
        w.write("System.out.println(\"El valor de la variable " + s1 + " es: \" + " + s1 + ");");
        w.newLine();

    }

}

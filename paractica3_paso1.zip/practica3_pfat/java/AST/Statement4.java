package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.SymbolTable;
import Compiler.Typ;
import Compiler.TypExc;

public class Statement4 implements Statement {

    public String s1;

    public Statement4(String s1) {

        this.s1 = s1;

    }

    @Override
    public int ComputeSt_type() throws CompilerExc {

        // TODO
        // Cambiamos el orden esta es la regla 2

        if (SymbolTable.getType(s1) == Typ.tint) {

            return Typ.tvoid;

        } else {

            throw new TypExc("Error en PRINT I PAREN IDENT TESIS");
        }
    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.newLine();
        w.write("System.out.println(\"El valor de la variable " + s1 + " es: \" + " + s1 + ");");
        w.newLine();

    }

}

package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class exp_parentesis implements Exp {

    public Exp exp1;

    public exp_parentesis(Exp exp1) {

        this.exp1 = exp1;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        return exp1.ComputeTyp();

    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {

        w.write("(");
        exp1.generateCode(w);
        w.write(")");
        // TODO
    }
}

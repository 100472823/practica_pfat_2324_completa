package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class Compara_igual implements Exp {

    public Exp exp1;
    public Exp exp2;
    // ningun atributo static en las clases ast

    // Privado Compute Typ
    private int type1;
    private int type2;

    public Compara_igual(Exp exp1, Exp exp2) {

        this.exp1 = exp1;
        this.exp2 = exp2;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO
        type1 = exp1.ComputeTyp();
        type2 = exp2.ComputeTyp();

        if (exp1.ComputeTyp() == exp2.ComputeTyp()) {

            return Typ.tbool;

        } else {

            throw new TypExc("Error en EXP IGUAL EXP");
        }
    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO

        if (type1 == Typ.tintset && type2 == Typ.tintset) {

            exp1.generateCode(w);
            w.write(".equals(");
            exp2.generateCode(w);
            w.write(")");

        } else {

            exp1.generateCode(w);
            w.write("==");
            exp2.generateCode(w);

        }

    }
}

package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class cero implements Exp {

  //  public Exp exp1;

   public cero() {

        
   
    }

      @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

    }


    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.write("new IntSetA(new Vector<>(Arrays.asList(");
        w.write("0");
        w.write(")");
        w.write(")");
        w.write(")");

    }


}
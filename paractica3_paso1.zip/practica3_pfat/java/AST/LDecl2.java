package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;

public class LDecl2 implements LDecl {

    public LDecl Ld;
    public Decl d;

    public LDecl2(Decl d, LDecl Ld) {

        this.d = d;
        this.Ld = Ld;

    }

    @Override
    public void ComputeAH1() throws CompilerExc {
        // TODO

        Ld.ComputeAH1();
        d.ComputeAH1();

    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO

        d.generateCode(w);
        w.write(";");
        Ld.generateCode(w);

    }
}

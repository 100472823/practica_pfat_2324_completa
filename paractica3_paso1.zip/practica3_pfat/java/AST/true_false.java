package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class true_false implements Exp {

    public final boolean s1;
    // esto como se asocia con el ident1

    public true_false(boolean s1) {
        this.s1 = s1;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO
        return Typ.tbool;
    }

    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        if (s1 == true) {

            w.write("true");

        } else {

            w.write("false");
        }

    }

}

package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;

public class entero implements Exp {

    public int s1;
    // esto como se asocia con el ident1

    public entero(int s1) {
        this.s1 = s1;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {

        // Seria final de la recursion
        // Del arbol,
        // Desde aqui iriamos Subiendo
        return Typ.tint;

    }
    // TODO

    @Override
    public void generateCode(BufferedWriter w) throws IOException {

        // TODO
        w.write(String.valueOf(s1));

    }
}

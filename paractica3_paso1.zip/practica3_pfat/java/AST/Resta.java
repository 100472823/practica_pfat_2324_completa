package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class Resta implements Exp {

    public Exp exp1;
    public Exp exp2;

    public Resta(Exp exp1, Exp exp2) {

        this.exp1 = exp1;
        this.exp2 = exp2;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        if ((exp1.ComputeTyp() == Typ.tint) && (exp2.ComputeTyp() == Typ.tint)) {

            return Typ.tint;

        } else if ((exp1.ComputeTyp() == Typ.tintset) && (exp2.ComputeTyp() == Typ.tintset)) {

            return Typ.tintset;

        } else {

            throw new TypExc("Error en EXP MENOS EXP");
        }
    }

    /// Diferencia suma.

    // Comprobadcion para que sean del mismo tipo, entonces restas pero si son de
    // intset, haces el metodo diferenciacion

    public void generateCode(BufferedWriter w) throws IOException {
        // TODO

        try {
            if ((exp1.ComputeTyp() == Typ.tint) && (exp2.ComputeTyp() == Typ.tint)) {
                exp1.generateCode(w);
                w.write("-");

            } else if ((exp1.ComputeTyp() == Typ.tintset) && (exp2.ComputeTyp() == Typ.tintset)) {

                exp1.generateCode(w);
                w.write(".setDif(");

            }
        } catch (CompilerExc | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        exp2.generateCode(w);

        try {
            if ((exp1.ComputeTyp() == Typ.tint) && (exp2.ComputeTyp() == Typ.tint)) {

            } else if ((exp1.ComputeTyp() == Typ.tintset) && (exp2.ComputeTyp() == Typ.tintset)) {

                w.write(")");

            }
        } catch (CompilerExc | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}

package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;

public interface ExpList {

    public int ComputeLTyp() throws CompilerExc;

    public void generateCode(BufferedWriter w) throws IOException;

}

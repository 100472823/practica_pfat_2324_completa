package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;

public interface Exp {

    public int ComputeTyp() throws CompilerExc;

    public void generateCode(BufferedWriter w) throws IOException;

}

package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class int2setj implements Exp {

    public Exp exp1;

   public int2setj(Exp exp1) {

        this.exp1 = exp1;
   
    }

      @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        if ((exp1.ComputeTyp() == Typ.tint) ) {

            return Typ.tintset;

        } else {

            throw new TypExc("Error en EXP int2set EXP");
        }
    }


    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.write("new IntSetA(new Vector<>(Arrays.asList(");
        exp1.generateCode(w);
        w.write(")");
        w.write(")");
        w.write(")");

    }


}
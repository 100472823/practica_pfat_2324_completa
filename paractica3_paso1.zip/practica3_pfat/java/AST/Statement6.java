package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.SymbolTable;
import Compiler.Typ;
import Compiler.TypExc;

public class Statement6 implements Statement {

    public Exp exp1;
    public StatementList stl1;
    public StatementList stl2;

    public Statement6(Exp exp1, StatementList stl1, StatementList stl2) {

        this.stl1 = stl1;
        this.exp1 = exp1;
        this.stl2 = stl2;

    }
 
    @Override
    public int ComputeSt_type() throws CompilerExc {
        // TODO

        int s1 = exp1.ComputeTyp();

        if ((exp1.ComputeTyp() == Typ.tbool) && (stl1.ComputeSt_type() == Typ.tvoid) && (stl2.ComputeSt_type() == Typ.tvoid)) {

            return Typ.tvoid;

        } else {

            throw new TypExc("Error en WHILE EXP DO STATEMENT LIST END, STATEMENT 6");
        }
    }


 
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.newLine();
        w.write("if (");
        exp1.generateCode(w);
        w.write(")  {");
        stl1.generateCode(w);
        w.write("}");
        w.write("else {");
        stl2.generateCode(w);
        w.write("}");

    }


    }



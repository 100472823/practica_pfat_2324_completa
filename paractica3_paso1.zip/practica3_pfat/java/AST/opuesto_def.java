package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class opuesto_def implements Exp {

    public Exp exp1;
    // esto como se asocia con el ident1

    public opuesto_def(Exp s1) {
        this.exp1 = s1;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        if (exp1.ComputeTyp() == Typ.tint) {

            return Typ.tint;

        } else {

            throw new TypExc("Error en MENOS EXP");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.write("-");
        exp1.generateCode(w);
    }

}

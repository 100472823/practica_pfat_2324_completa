package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class Compara_menor implements Exp {

    public Exp exp1;
    public Exp exp2;
    // ningun atributo static en las clases ast

    public Compara_menor(Exp exp1, Exp exp2) {

        this.exp1 = exp1;
        this.exp2 = exp2;

    }

    public int ComputeTyp() throws CompilerExc {
        // TODO

        if (exp1.ComputeTyp() == Typ.tint && exp2.ComputeTyp() == Typ.tint) {

            return Typ.tbool;

        } else {

            throw new TypExc("Error en EXP MENOR EXP");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        exp1.generateCode(w);
        w.write("<");
        exp2.generateCode(w);

    }

}

package AST;

import Compiler.*;
import java.io.*;

public interface IdentList {

    // interfaz implementada por las distintas
    // reglas de produccion
    public void computeAH1(int type) throws CompilerExc;

    public void generateCode(BufferedWriter w) throws IOException;

}

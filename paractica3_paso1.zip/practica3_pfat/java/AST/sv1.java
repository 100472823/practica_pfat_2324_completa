package AST;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import Compiler.CompilerExc;

public class sv1 implements s {

    public String i1;
    public LDecl Ld1;
    public Body b1;

    // BufferedReader br = new BufferedReader(new FileReader(i1));

    public sv1(String i1, LDecl Ld1, Body b1) {

        this.i1 = i1;
        this.Ld1 = Ld1;
        this.b1 = b1;

    }

    @Override
    public void ComputeAH1() throws CompilerExc {
        // TODO
        Ld1.ComputeAH1();
    }

    @Override
    public int ComputeSt_type() throws CompilerExc {
        // TODO

        return b1.ComputeSt_type();
    }

    @Override
    public void codeGenerator() {
        try {
            BufferedWriter w = new BufferedWriter(new FileWriter(i1 + ".java"));
            w.write("import GeneratedCodeLib.*;");
            w.newLine();
            w.write("import java.util.*;");
            w.newLine();
            w.write("import Errors.EmptySetException;");
            w.newLine();
            w.write("public class " + i1 + " {");
            w.newLine();
            w.newLine();
            Ld1.generateCode(w);
            w.newLine();
            w.write("public static void main (String [] args) throws EmptySetException {");
            w.newLine();
            b1.generateCode(w);
            w.write("}");
            w.newLine();
            w.write("}");
            w.newLine();
            w.close();
            System.out.println("Code generated in file " + i1 + ".java");
        } catch (IOException e) {
            System.out.println("IO error trying to write in file " +
                    i1 + ".java");
        }

    }

}

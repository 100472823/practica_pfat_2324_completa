package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;

public class StatementList1 implements StatementList {

    public Statement statement1;

    public StatementList1(Statement s1) {

        this.statement1 = s1;

    }

    public int ComputeSt_type() throws CompilerExc {

        // Mi atributo St_type
        // Va a ser el resultado de la funcion
        // De Statement 1 que es mi hijo

        return statement1.ComputeSt_type();

    }

    public void generateCode(BufferedWriter w) throws IOException {

        statement1.generateCode(w);

    }

}

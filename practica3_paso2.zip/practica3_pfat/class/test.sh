#!/bin/bash

java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/Ejem1/ejem1.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/Ejem2/ejem2.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/Ejem3/ejem3.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/Ejem4/ejem4.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/Ejem5/ejem5.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/Ejem6/ejem6.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/Ejem7/ejem7.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/Ejem8/ejem8.prg

java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/ErrLex1/errLex1.prg

java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/ErrSem1/errSem1.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/ErrSem2/errSem2.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/ErrSem3/errSem3.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/ErrSem4/errSem4.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/ErrSem5/errSem5.prg

java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/ErrSint1/errSint1.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/ErrSint2/errSint2.prg
java -cp .:java-cup-11b-runtime.jar Main ../ejemplos/ErrSint3/errSint3.prg
package Compiler;

public class TableEntry {
  private String name;
  private int type;

  public TableEntry(String n, int t) {
    name = n;
    type = t;
  }

  public String getName() {
    return name;
  }

  public int getType() {
    return type;
  }
}

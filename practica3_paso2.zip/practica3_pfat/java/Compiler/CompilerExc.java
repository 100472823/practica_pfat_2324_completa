package Compiler;

public class CompilerExc extends Exception {
}

package Compiler;

public class Typ {

    public static final int tint = 1;
    public static final int tbool = 2;
    public static final int tintset = 3;
    public static final int tvoid = 4;

    // Hay que comprobarlo
    // Y si no preguntarle,
    // el resultado de TYPE

    public static String typToString(int typ) {
        if (typ == tint) {
            return "int";
        } else if (typ == tbool) {
            return "boolean";
        } else {

            return "intset";

        }

    }

    // Entender bien esto,

}

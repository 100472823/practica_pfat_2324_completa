package GeneratedCodeLib;

import java.util.*;
import Errors.*;

public class IntSetA {
    private final Vector<Integer> intSetData;

    public IntSetA() {
        intSetData = new Vector<Integer>();
    }

    public IntSetA(Vector<Integer> v) {
        int i;
        Object[] b = v.toArray();
        int[] a = new int[b.length];

        for (i = 0; i < b.length; i++) {
            a[i] = ((Integer) b[i]).intValue();
        }

        Arrays.sort(a);
        intSetData = new Vector();

        for (i = 0; i < a.length; i++) {
            if ((i > 0) && (a[i] == a[i - 1]))
                continue;
            intSetData.add(a[i]);
        }
    }

    public boolean belongsTo(int i) {
        return intSetData.contains(i);
    }

    public Vector<Integer> getIntSetData() {
        return intSetData;
    }

    public IntSetA unionSet(IntSetA b) {
        // añadimos los elementos que le falten a A, en B.
        Vector<Integer> Juntos = new Vector<>(this.intSetData);
        for (Integer element : b.getIntSetData()) {
            if (!Juntos.contains(element)) {
                Juntos.add(element);

            }

        }
        return new IntSetA(Juntos);
    }

    public boolean equals(IntSetA is) {
        Vector<Integer> isV = is.getIntSetData();
        int isSz = isV.size();
        int i;

        if (intSetData.size() != isSz)
            return false;

        i = 0;

        while (i < isSz) {
            if (isV.get(i) != intSetData.get(i))
                return false;
            i++;
        }
        return true;
    }

    public IntSetA intersectionSet(IntSetA b) {
        Vector<Integer> a = new Vector<>(this.intSetData);
        Vector<Integer> intersection = new Vector<>();
        for (int i = 0; i < a.size(); i++) {
            Integer element = a.get(i);
            for (Integer element1 : b.getIntSetData()) {
                if (element == (element1)) {
                    intersection.add(element);

                }

            }
        }
        return new IntSetA(intersection);

    }

    public int card() {
        return intSetData.size();
    }

    public int lowestElem() throws EmptySetException {
        if (intSetData.size() == 0) {
            throw new EmptySetException();
        }
        return intSetData.get(0).intValue();
    }

    public IntSetA setDif(IntSetA b) {
        Vector<Integer> differenciaData = new Vector<>(this.intSetData);
        differenciaData.removeAll(b.getIntSetData());
        IntSetA resultado = new IntSetA(differenciaData);
        return resultado;
    }
}

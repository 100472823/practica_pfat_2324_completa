import GeneratedCodeLib.*;
import java.util.*;
import Errors.EmptySetException;
public class EjemN2 {


 public static IntSetA a,b,c,d;

 public static int a1,b1,c1,d1;
public static void main (String [] args) throws EmptySetException {

a = new IntSetA(new Vector<>(Arrays.asList( 0,1,3,5,7,9)));
b = new IntSetA(new Vector<>(Arrays.asList( 0,2,4,6,8)));
c = a.unionSet(b);
d = a.intersectionSet(new IntSetA(new Vector<>(Arrays.asList(1+a.card()))));
a1 = a.card();
System.out.println("El valor de la variable a1 es: " + a1);

b1 = b.card();
System.out.println("El valor de la variable b1 es: " + b1);

c1 = c.card();
System.out.println("El valor de la variable c1 es: " + c1);

d1 = d.card();
System.out.println("El valor de la variable d1 es: " + d1);
}
}

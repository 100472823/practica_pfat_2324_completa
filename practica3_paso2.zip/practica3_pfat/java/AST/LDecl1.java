package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;

public class LDecl1 implements LDecl {
    // no se si hay que guardarlo private Decl ;

    public Decl decl;

    public LDecl1(Decl d) {

        this.decl = d;
    }

    @Override
    public void ComputeAH1() throws CompilerExc {
        // TODO
        decl.ComputeAH1();
    }

    public void generateCode(BufferedWriter w) throws IOException {

        // Void, cambiar.
        // directamente ejecuta dcl
        w.newLine();
        decl.generateCode(w);
        w.write(";");

    }

}

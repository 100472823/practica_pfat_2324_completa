package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;

public interface StatementList {

    public int ComputeSt_type() throws CompilerExc;

    public void generateCode(BufferedWriter w) throws IOException;

}

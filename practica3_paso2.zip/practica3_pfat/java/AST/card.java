package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class card implements Exp {

    public Exp exp1;

    public card(Exp exp1) {

        this.exp1 = exp1;

    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        if (exp1.ComputeTyp() == Typ.tintset) {

            return Typ.tint;

        } else {
            // Tendremos que Modificar todavia
            // La clase TypExc
            throw new TypExc("Error en CARD PARENT EXP TESIS ");

        }

    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO

        exp1.generateCode(w);
        w.write(".card()");

    }

}

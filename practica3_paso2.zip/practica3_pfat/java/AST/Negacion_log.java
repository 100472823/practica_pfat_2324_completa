package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.Typ;
import Compiler.TypExc;

public class Negacion_log implements Exp {

    public Exp exp1;

    public Negacion_log(Exp s1) {

        this.exp1 = s1;
    }

    @Override
    public int ComputeTyp() throws CompilerExc {
        // TODO

        if (exp1.ComputeTyp() == Typ.tbool) {

            return Typ.tbool;

        } else {

            throw new TypExc("Error en NOT EXP");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.write("!");
        exp1.generateCode(w);
    }

}

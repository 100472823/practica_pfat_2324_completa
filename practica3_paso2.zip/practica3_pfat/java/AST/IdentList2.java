package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.CompilerExc;
import Compiler.SymbolTable;

public class IdentList2 implements IdentList {

    public IdentList idl1;
    public String i1;
    private int ah1;

    public IdentList2(String i1, IdentList idl1) {

        this.idl1 = idl1;
        this.i1 = i1;

    }

    public void computeAH1(int type) throws CompilerExc {
        // TODO Auto-generated method stub
        // Me pasa mi padre el valor de
        // Mi atributo,
        // Lo guardo
        // Le paso al hijo el suyo
        ah1 = type;
        idl1.computeAH1(ah1);
        SymbolTable.newEntry(i1, ah1);

    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        w.write(i1 + ",");
        idl1.generateCode(w);

    }
}

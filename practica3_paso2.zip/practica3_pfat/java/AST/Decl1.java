package AST;

import Compiler.*;
import java.io.*;

public class Decl1 implements Decl {

    public int i1;
    public IdentList il1;

    public Decl1(int i1, IdentList il1) {

        this.i1 = i1;
        this.il1 = il1;

    }

    public void ComputeAH1() throws CompilerExc {
        // Yo soy el padre le paso a mi hijo
        // El valor de su atributo
        // se lo paso para que lo tenga y
        // que lo guarde en la tabla
        int ah1 = i1;
        il1.computeAH1(ah1);
    }
    // EN el generado de la clase, public static void main (args)

    public static String typToString(int typ) {
        if (typ == Typ.tint) {
            return "int";
        } else if (typ == Typ.tbool) {
            return "boolean";
        } else {

            return "IntSetA";

        }

    }

    @Override
    public void generateCode(BufferedWriter w) throws IOException {
        // TODO
        // Dependiendo del tipo que sea i1
        w.newLine();
        w.write(" public static " + typToString(i1) + " ");
        il1.generateCode(w);

    }

}

import AST.*;

import Parser.*;
import Lexer.*;
import java.io.*;
import Compiler.*;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

  public static void main(String args[]) throws Exception {
    java.io.BufferedReader in;
    Yylex sc;
    parser p;
    java_cup.runtime.Symbol sroot;
    boolean error = false;

    // El primer parametro es el nombre del fichero con el programa
    if (args.length < 1) {
      System.out.println(
          "Uso: java Main <nombre_fichero>");
      error = true;
    }

    // Analisis lexico y sintactico

    if (!error) {
      try {
        in = new java.io.BufferedReader(new java.io.FileReader(args[0]));
        sc = new Yylex(in);
        p = new parser(sc);
        sroot = p.parse();
        System.out.println("Analisis lexico y sintactico correctos");

        s root = (s) sroot.value;
        root.ComputeAH1();
        root.ComputeSt_type();
        System.out.println("Analisis semantico correcto");

        // Mirar enunciado practica 3, bien.
        // Crear una clase, conforme el nombre del programa.

        // Code generation
        if (!error)
          root.codeGenerator();

      } catch (IOException e) {
        System.out.println("Error abriendo fichero: " + args[0]);
        error = true;
      }
    }

  }

}

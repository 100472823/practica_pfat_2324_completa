#!/bin/bash

# Compilar los archivos Java
for i in {1..8}
do
  echo "Compilando Ejem$i.java"
  javac Ejem$i.java
done

# Ejecutar los archivos compilados, asumiendo que cada uno tiene un método main
for i in {1..8}
do
  echo "Ejecutando Ejem$i"
  java Ejem$i
done